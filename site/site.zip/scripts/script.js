(function() {
    'use strict';

    // New instance of WallopSlider
    var photoSlider = new WallopSlider('.photo-slider');

})();
